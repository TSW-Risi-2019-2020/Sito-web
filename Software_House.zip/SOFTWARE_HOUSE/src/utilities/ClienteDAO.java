package utilities;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import webSite.SoftwareHouseDB;

public class ClienteDAO 
{
	private static Connection conn;
	private static ResultSet rs;
	private static SoftwareHouseDB db;
	
	
	//costruttore
	public ClienteDAO()
	{
		conn=null;
		rs=null;
		db=new SoftwareHouseDB();
	}
	
	public int insertCliente(Cliente c)
	{
		int n=0;
		conn=SoftwareHouseDB.getConnection();
		String query="insert into cliente (UsernameCL, NomeCL, CognomeCL, Data_nascitaCL, IndirizzoCL, EmailCL, PasswordCL) "
				+ "values('"+c.getUsernameCL()+"','"+c.getNomeCL()+"','"+c.getCognomeCL()+"','"+c.getData_nascitaCL()+"','"+
				c.getIndirizzoCL()+"','"+c.getEmailCL()+"',md5(md5('"+c.getPasswordCL()+"C6H12O6')));";
			
		n=db.execUpdate(query, conn);
		SoftwareHouseDB.releaseConnection(conn);
		return n;
			
	}
	

	//Cliente Singolo
	public static Cliente findCliente(String emailCL, String passwordCL) 
	{
		
		Cliente cliente=null;
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="SELECT * FROM CLIENTE WHERE EmailCL='"+emailCL+"' AND PasswordCL=md5(md5('"+passwordCL+"C6H12O6'));";
			rs=db.execQuery(query, conn);
			if(rs.next()) 
			{
				cliente= new Cliente	(
											rs.getString("UsernameCL"), rs.getString("NomeCL"),
											rs.getString("CognomeCL"), rs.getString("Data_nascitaCL"),
											rs.getString("IndirizzoCL"), rs.getString("EmailCL"), rs.getString("PasswordCL")
										);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return cliente;
				
	}
	
}
