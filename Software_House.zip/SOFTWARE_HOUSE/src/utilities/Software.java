package utilities;

public final class Software
{
	private int CodiceS;
	private String NomeS;
	private String DescrizioneVetrinaS;
	private String ImmagineVetrinaS;
	private String DataRilascioS;
	private String TitoloDescrizioneSinteticaS;
	private String DescrizioneSinteticaS;
	private String ImmagineDescrizioneS;
	private String SpecificheS;
	private float PrezzoS;
	
	//Costruttore 
	public Software(int codiceS, String nomeS, String dataRilascioS, String immagineDescrizioneS, String specificheS,float prezzoS)
	{
		CodiceS = codiceS;
		NomeS = nomeS;
		DataRilascioS = dataRilascioS;
		ImmagineDescrizioneS = immagineDescrizioneS;
		SpecificheS = specificheS;
		PrezzoS = prezzoS;
	}
	public String toString() 
	{
		return "Software [CodiceS=" + CodiceS + ", NomeS=" + NomeS + ", DataRilascioS=" + DataRilascioS
				+ ", ImmagineDescrizioneS="+ ImmagineDescrizioneS + ", SpecificheS=" + SpecificheS + ", PrezzoS=" + PrezzoS + "]";
	}
	
	
	//Costruttore
	public Software (int codiceS, String nomeS, String descrizioneVetrinaS, String immagineVetrinaS, String dataRilascioS, String titoloDescrizioneSinteticaS, String descrizioneSinteticaS, String immagineDescrizioneS,String specificheS, float prezzoS) 
	{
		CodiceS = codiceS;
		NomeS = nomeS;
		DescrizioneVetrinaS = descrizioneVetrinaS;
		ImmagineVetrinaS = immagineVetrinaS;
		DataRilascioS = dataRilascioS;
		TitoloDescrizioneSinteticaS = titoloDescrizioneSinteticaS;
		DescrizioneSinteticaS = descrizioneSinteticaS;
		ImmagineDescrizioneS = immagineDescrizioneS;
		SpecificheS = specificheS;
		PrezzoS = prezzoS;
	}

	public int getCodiceS() 
	{
		return CodiceS;
	}
	
	public String getNomeS() 
	{
		return NomeS;
	}
	
	public String getDescrizioneVetrinaS() 
	{
		return DescrizioneVetrinaS;
	}
	
	public String getImmagineVetrinaS() 
	{
		return ImmagineVetrinaS;
	}
	
	public String getDataRilascioS() 
	{
		return DataRilascioS;
	}
	
	public String getTitoloDescrizioneSinteticaS() 
	{
		return TitoloDescrizioneSinteticaS;
	}
	
	public String getDescrizioneSinteticaS() 
	{
		return DescrizioneSinteticaS;
	}
	
	public String getImmagineDescrizioneS() 
	{
		return ImmagineDescrizioneS;
	}
	
	public String getSpecificheS() 
	{
		return SpecificheS;
	}
	
	public float getPrezzoS() 
	{
		return PrezzoS;
	}
}
