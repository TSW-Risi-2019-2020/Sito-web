package utilities;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import webSite.SoftwareHouseDB;

public class SoftwareDAO 
{
	private static Connection conn;
	private static ResultSet rs;
	private static SoftwareHouseDB db;
	
	//costruttore
	public SoftwareDAO()
	{
		conn=null;
		rs=null;
		db=new SoftwareHouseDB();
	}
	
	//Software Singolo
	public static Software findSoftware(int codiceS) 
	{
		
		Software software=null;
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="SELECT * FROM SOFTWARE WHERE CodiceS="+codiceS+";";
			rs=db.execQuery(query, conn);
			if(rs.next()) 
			{
				software= new Software	(
											rs.getInt("CodiceS"),rs.getString("NomeS"),
											rs.getString("DescrizioneVetrinaS"),rs.getString("ImmagineVetrinaS"),
											rs.getString("DataRilascioS"),rs.getString("TitoloDescrizioneSinteticaS"),
											rs.getString("DescrizioneSinteticaS"), rs.getString("ImmagineDescrizioneS"),
											rs.getString("SpecificheS"), rs.getFloat("PrezzoS")
										);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return software;
				
	}
	//software
	public ArrayList<Software> getSoftware() 
	{
		ArrayList<Software> software=new ArrayList<Software>();
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="SELECT * FROM SOFTWARE ORDER BY DATARILASCIOS DESC;";
			rs=db.execQuery(query, conn);
			while(rs.next())
			{
				software.add(
								new Software	(
													rs.getInt("CodiceS"),rs.getString("NomeS"),
													rs.getString("DescrizioneVetrinaS"),rs.getString("ImmagineVetrinaS"),
													rs.getString("DataRilascioS"),rs.getString("TitoloDescrizioneSinteticaS"),
													rs.getString("DescrizioneSinteticaS"), rs.getString("ImmagineDescrizioneS"),
													rs.getString("SpecificheS"), rs.getFloat("PrezzoS")
												)
							);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return software;
	}
}
