package utilities;

public class Corsi 
{
	private int CodiceC;
	private String NomeC;
	private String DescrizioneVetrinaC;
	private String ImmagineVetrinaC;
	private String TitoloDescrizioneSinteticaC;
	private String DescrizioneSinteticaC;
	private String ImmagineDescrizioneC;
	private String SpecificheC;
	private int NumEsamiC;
	
	//Costruttore
	public Corsi (int codiceC, String nomeC, String descrizioneVetrinaC, String immagineVetrinaC, String titoloDescrizioneSinteticaC, String descrizioneSinteticaC, String immagineDescrizioneC,String specificheC, int numEsamiC) 
	{
		CodiceC = codiceC;
		NomeC = nomeC;
		DescrizioneVetrinaC = descrizioneVetrinaC;
		ImmagineVetrinaC = immagineVetrinaC;
		TitoloDescrizioneSinteticaC = titoloDescrizioneSinteticaC;
		DescrizioneSinteticaC = descrizioneSinteticaC;
		ImmagineDescrizioneC = immagineDescrizioneC;
		SpecificheC = specificheC;
		NumEsamiC=numEsamiC;
	}

	public int getCodiceC() 
	{
		return CodiceC;
	}

	public String getNomeC() 
	{
		return NomeC;
	}

	public String getDescrizioneVetrinaC() 
	{
		return DescrizioneVetrinaC;
	}

	public String getImmagineVetrinaC() 
	{
		return ImmagineVetrinaC;
	}

	public String getTitoloDescrizioneSinteticaC() 
	{
		return TitoloDescrizioneSinteticaC;
	}

	public String getDescrizioneSinteticaC() 
	{
		return DescrizioneSinteticaC;
	}

	public String getImmagineDescrizioneC() 
	{
		return ImmagineDescrizioneC;
	}

	public String getSpecificheC() 
	{
		return SpecificheC;
	}

	public int getNumEsamiC() 
	{
		return NumEsamiC;
	}
}
