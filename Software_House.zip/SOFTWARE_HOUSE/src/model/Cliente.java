package model;

public class Cliente 
{
	private String Tipo;
	private String UsernameCL;
	private String NomeCL;
	private String CognomeCL;
	private String Data_nascitaCL;
	private String IndirizzoCL;
	private String EmailCL;
	private String PasswordCL;
	
	//costruttore
	public Cliente(String tipo,String usernameCL, String nomeCL, String cognomeCL, String data_nascitaCL, String indirizzoCL, String emailCL, String passwordCL) 
	{
		Tipo=tipo;
		UsernameCL = usernameCL;
		NomeCL = nomeCL;
		CognomeCL = cognomeCL;
		Data_nascitaCL = data_nascitaCL;
		IndirizzoCL = indirizzoCL;
		EmailCL = emailCL;
		PasswordCL = passwordCL;
	}

	public String getUsernameCL() 
	{
		return UsernameCL;
	}

	public String getNomeCL() 
	{
		return NomeCL;
	}

	public String getCognomeCL() 
	{
		return CognomeCL;
	}

	public String getData_nascitaCL() 
	{
		return Data_nascitaCL;
	}

	public String getIndirizzoCL() 
	{
		return IndirizzoCL;
	}

	public String getEmailCL() 
	{
		return EmailCL;
	}

	public String getPasswordCL() 
	{
		return PasswordCL;
	}

	public String getTipo()
	{
		return Tipo;
	}

	public String toString() 
	{
		return "Cliente [CodiceFiscaleCL=" + UsernameCL + ", NomeCL=" + NomeCL + ", CognomeCL=" + CognomeCL+ ", Data_nascitaCL=" + Data_nascitaCL + ", IndirizzoCL=" + IndirizzoCL + ", EmailCL=" + EmailCL+ ", PasswordCL=" + PasswordCL + "]";
	}
}
