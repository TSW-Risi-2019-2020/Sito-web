package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import webSite.SoftwareHouseDB;

public class SegueDAO 
{

	private static Connection conn;
	private static ResultSet rs;
	private static SoftwareHouseDB db;
	
	//costruttore
	public SegueDAO()
	{
		conn=null;
		rs=null;
		db=SoftwareHouseDB.getDB();
	}
	public static ArrayList<Segue> getCorsiSeguiti(String email) 
	{
		ArrayList<Segue> seguiti=new ArrayList<Segue>();
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="select NomeC,Numero_esami_conseguiti,Data_iscrizione,NumEsamiC,Corso_CodiceC, Cliente_EmailCL from segue inner join corso on codicec=corso_Codicec where codicec in (select Corso_CodiceC from segue where Cliente_EmailCL='"+email+"') and Cliente_EmailCL='"+email+"';";
			rs=db.execQuery(query, conn);
			while(rs.next())
			{
				seguiti.add(
								new Segue	(
													rs.getString("NomeC"),
													Integer.parseInt(rs.getString("Numero_esami_conseguiti")),
													rs.getString("Data_iscrizione"),
													Integer.parseInt(rs.getString("NumEsamiC")), 
													Integer.parseInt(rs.getString("Corso_CodiceC")),
													rs.getString("Cliente_EmailCL")
												)
							);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return seguiti;
	}
	

	public int insertSegue(String data, String emailCL, int codiceC)
	{
		int n=0;
		conn=SoftwareHouseDB.getConnection();
		String query=	"insert into segue (Cliente_EmailCL,Corso_CodiceC, Data_iscrizione)" + 
						"values ('" + emailCL+"',"+codiceC+",'"+data+"');";
		n=db.execUpdate(query, conn);
		SoftwareHouseDB.releaseConnection(conn);
		return n;	
	}
	
	public static boolean updateSegue (int codiceC,String emailCL)
	{
		int n;
		conn=SoftwareHouseDB.getConnection();
		String query="update segue set Numero_esami_conseguiti=(select Numero_esami_conseguiti+1 where Corso_CodiceC='"+codiceC+"' and Cliente_EmailCL='"+emailCL+"') where Corso_CodiceC='"+codiceC+"' and Cliente_EmailCL='"+emailCL+"';";		
		n=db.execUpdate(query, conn);	
		SoftwareHouseDB.releaseConnection(conn);
		return (n==1);
	}
}
