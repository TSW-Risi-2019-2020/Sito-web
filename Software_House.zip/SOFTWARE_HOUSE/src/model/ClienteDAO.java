package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import webSite.SoftwareHouseDB;

public class ClienteDAO 
{
	private static Connection conn;
	private static ResultSet rs;
	private static SoftwareHouseDB db;
	
	//costruttore
	public ClienteDAO()
	{
		conn=null;
		rs=null;
		db=SoftwareHouseDB.getDB();
	}
	
	public int insertCliente(Cliente c)
	{
		int n=0;
		conn=SoftwareHouseDB.getConnection();
		String query="insert into cliente (UsernameCL, NomeCL, CognomeCL, Data_nascitaCL, IndirizzoCL, EmailCL, PasswordCL) "
				+ "values('"+c.getUsernameCL()+"','"+c.getNomeCL()+"','"+c.getCognomeCL()+"','"+c.getData_nascitaCL()+"','"+
				c.getIndirizzoCL()+"','"+c.getEmailCL()+"',md5('"+c.getPasswordCL()+"'));";
		n=db.execUpdate(query, conn);
		SoftwareHouseDB.releaseConnection(conn);
		return n;	
	}
	
	public int updateCliente (String usernameCL, String emailCL, String passwordCL)
	{
		int n;
		conn=SoftwareHouseDB.getConnection();
		String query="start transaction;";		
		db.execUpdate(query, conn);
		query="update cliente set UsernameCL='"+usernameCL+"' where EmailCL='"+emailCL+"';";		
		db.execUpdate(query, conn);
		query="update cliente set PasswordCL=md5('"+passwordCL+"') where EmailCL='"+emailCL+"';";
		n=db.execUpdate(query, conn);
		query="commit;";
		db.execUpdate(query, conn);
		SoftwareHouseDB.releaseConnection(conn);
		return n;
	}

	public int updatePassword(String emailCL, String passwordCL)
	{
		int n;
		conn=SoftwareHouseDB.getConnection();
		String query="update cliente set PasswordCL=md5('"+passwordCL+"') where EmailCL='"+emailCL+"';";
		n=db.execUpdate(query, conn);
		SoftwareHouseDB.releaseConnection(conn);
		return n;
	}
	
	//Cliente Singolo
	public static Cliente findCliente(String emailCL, String passwordCL) 
	{
		
		Cliente cliente=null;
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="SELECT * FROM CLIENTE WHERE EmailCL='"+emailCL+"' AND PasswordCL=md5('"+passwordCL+"');";
			rs=db.execQuery(query, conn);
			if(rs.next()) 
			{
				cliente= new Cliente	(
											rs.getString("Tipo"),
											rs.getString("UsernameCL"), rs.getString("NomeCL"),
											rs.getString("CognomeCL"), rs.getString("Data_nascitaCL"),
											rs.getString("IndirizzoCL"), rs.getString("EmailCL"), rs.getString("PasswordCL")
										);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return cliente;	
	}
	

	//Cliente Singolo
	public static Cliente findCliente(String emailCL) 
	{
		
		Cliente cliente=null;
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="SELECT * FROM CLIENTE WHERE EmailCL='"+emailCL+"';";
			rs=db.execQuery(query, conn);
			if(rs.next()) 
			{
				cliente= new Cliente	(
											rs.getString("Tipo"),
											rs.getString("UsernameCL"), rs.getString("NomeCL"),
											rs.getString("CognomeCL"), rs.getString("Data_nascitaCL"),
											rs.getString("IndirizzoCL"), rs.getString("EmailCL"), rs.getString("PasswordCL")
										);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return cliente;	
	}
	
	public ArrayList<Cliente> getClienti() 
	{
		ArrayList<Cliente> clienti=new ArrayList<Cliente>();
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="SELECT * FROM cliente WHERE tipo='S';";
			rs=db.execQuery(query, conn);
			while(rs.next())
			{
				clienti.add(
								new Cliente	(
												rs.getString("Tipo"),
												rs.getString("UsernameCL"), rs.getString("NomeCL"),
												rs.getString("CognomeCL"), rs.getString("Data_nascitaCL"),
												rs.getString("IndirizzoCL"), rs.getString("EmailCL"), rs.getString("PasswordCL")
											)
							);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return clienti;
	}
	
	public int upgradeCliente(String email)
	{
		int n;
		conn=SoftwareHouseDB.getConnection();
		String query="update cliente set tipo='A' where EmailCL='"+email+"';";		
		n=db.execUpdate(query, conn);	
		SoftwareHouseDB.releaseConnection(conn);
		return n;
	}
	
	//ricerca email 
	public static boolean findEmail(String emailCL) 
	{
		boolean esito=false;
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="select EmailCL from cliente where EmailCL='"+emailCL+"';";
			rs=db.execQuery(query, conn);
			if(rs.next()) 
				esito=true;
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return esito;	
	}
	
}
