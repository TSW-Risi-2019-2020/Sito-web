package model;

public class Segue {
	private String nomeCorso;
	private int numeroEsamiConseguiti;
	private String dataIscrizione;
	private int numeroEsami;
	private int codiceC;
	private String emailCL;
	
	//costruttore 
	public Segue(String nomeCorso, int numeroEsamiConseguiti, String dataIscrizione, int numeroEsami) 
	{
		this.nomeCorso = nomeCorso;
		this.numeroEsamiConseguiti = numeroEsamiConseguiti;
		this.dataIscrizione = dataIscrizione;
		this.numeroEsami = numeroEsami;
	}
	
	//costruttore
	public Segue(String nomeCorso, int numeroEsamiConseguiti, String dataIscrizione, int numeroEsami, int codiceC, String emailCL) 
	{
		this.nomeCorso = nomeCorso;
		this.numeroEsamiConseguiti = numeroEsamiConseguiti;
		this.dataIscrizione = dataIscrizione;
		this.numeroEsami = numeroEsami;
		this.codiceC=codiceC;
		this.emailCL=emailCL;
	}
	
	public int getNumeroEsami() 
	{
		return numeroEsami;
	}

	public String getNomeCorso()
	{
		return nomeCorso;
	}
	
	public int getNumeroEsamiConseguiti()
	{
		return numeroEsamiConseguiti;
	}
	
	public String getDataIscrizione()
	{
		return dataIscrizione;
	}
	
	public String getEmailCL()
	{
		return emailCL;
	}
	
	public int getCodiceC()
	{
		return codiceC;
	}
}
