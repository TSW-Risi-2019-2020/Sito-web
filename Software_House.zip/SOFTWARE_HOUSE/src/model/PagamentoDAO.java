package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import webSite.SoftwareHouseDB;

public class PagamentoDAO 
{
	private static Connection conn;
	private static ResultSet rs;
	private static SoftwareHouseDB db;
	
	//costruttore
	public PagamentoDAO()
	{
		conn=null;
		rs=null;
		db=SoftwareHouseDB.getDB();
	}
	public static ArrayList<Pagamento> getCarte(String email) 
	{
		ArrayList<Pagamento> carte=new ArrayList<Pagamento>();
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="select NumCarta, DataScadenza from pagamento where Cliente_EmailCL='"+email+"';";
			rs=db.execQuery(query, conn);
			while(rs.next())
			{
				carte.add(
								new Pagamento	(
													rs.getString("NumCarta"),
													rs.getString("DataScadenza")
												)
							);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return carte;
	}
	

	public int insertPagamento(String numCarta, String dataScadenza, String emailCL, String cVC) 
	{
		int n;
		conn=SoftwareHouseDB.getConnection();
		String query="insert into pagamento(NumCarta,DataScadenza,Cliente_EmailCL,CVC) values ('"+numCarta+"','"+dataScadenza+"','"+emailCL+"',md5(md5('"+cVC+"NaCl')));";
		n= db.execUpdate(query, conn);
		SoftwareHouseDB.releaseConnection(conn);
		return n;
	}
	public static boolean CheckCarta(String numCarta, String CVC, String emailCL) 
	{
		boolean esito=false;
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="select * from pagamento where numCarta='"+numCarta+"'and CVC=md5(md5('"+CVC+"NaCl')) and Cliente_EmailCL='"+emailCL+"';";
			rs=db.execQuery(query, conn);
			if(rs.next())
				esito=true;
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return esito;
	}
	
	
}
