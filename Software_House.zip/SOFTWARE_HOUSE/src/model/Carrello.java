package model;

public class Carrello 
{
	private String EmailCL;
	private int CodiceS;
	private String NomeS;
	private float PrezzoS;
	

	public Carrello(String emailCL, int codiceS, String nomeS, float prezzoS) 
	{
		EmailCL = emailCL;
		CodiceS = codiceS;
		NomeS = nomeS;
		PrezzoS = prezzoS;
	}

	public String getEmailCL() 
	{
		return EmailCL;
	}
	
	public int getCodiceS() 
	{
		return CodiceS;
	}
	
	public String getNomeS() 
	{
		return NomeS;
	}
	
	public float getPrezzoS() 
	{
		return PrezzoS;
	}


	public String toString() 
	{
		return "Carrello [EmailCL=" + EmailCL + ", CodiceS=" + CodiceS + ", NomeS=" + NomeS + ", PrezzoS=" + PrezzoS+ "]";
	}
	
	public boolean equals(Object anObject)
	{
		if(anObject!=null && getClass()!=anObject.getClass())
			return false;
		Carrello c=(Carrello)anObject;
		Float f1=PrezzoS, f2=c.getPrezzoS();
		return (EmailCL.equals(c.getEmailCL()) && (CodiceS==c.getCodiceS() && (NomeS.equals(c.getNomeS()) && f1.equals(f2))));
	}
	
}
