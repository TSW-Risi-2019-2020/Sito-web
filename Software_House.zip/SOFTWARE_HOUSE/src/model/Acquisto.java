package model;

public class Acquisto {
	private String codiceS;
	private String dataAcquisto;
	private String prezzo;
	private String nomeS;
	public Acquisto(String codiceS, String dataAcquisto, String prezzo, String nomeS) 
	{
		this.codiceS = codiceS;
		this.dataAcquisto = dataAcquisto;
		this.prezzo = prezzo;
		this.nomeS = nomeS;
	}
	public String getCodiceS() {
		return codiceS;
	}
	public void setCodiceS(String codiceS) 
	{
		this.codiceS = codiceS;
	}
	public String getDataAcquisto() 
	{
		return dataAcquisto;
	}
	public void setDataAcquisto(String dataAcquisto)
	{
		this.dataAcquisto = dataAcquisto;
	}
	public String getPrezzo()
	{
		return prezzo;
	}
	public void setPrezzo(String prezzo) 
	{
		this.prezzo = prezzo;
	}
	public String getNomeS() 
	{
		return nomeS;
	}
	public void setNomeS(String nomeS)
	{
		this.nomeS = nomeS;
	}

}
