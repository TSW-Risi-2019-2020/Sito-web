package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import webSite.SoftwareHouseDB;

public class CorsoDAO 
{
	private static Connection conn;
	private static ResultSet rs;
	private static SoftwareHouseDB db;
	
	//costruttore
	public CorsoDAO()
	{
		conn=null;
		rs=null;
		db=SoftwareHouseDB.getDB();
	}
	
	//corsi
	public ArrayList<Corsi> getCorsi() 
	{
		ArrayList<Corsi> corsi=new ArrayList<Corsi>();
		try
		{
			conn=SoftwareHouseDB.getConnection();
			String query="SELECT * FROM CORSO WHERE DISPONIBILE=true ORDER BY NUMESAMIC DESC;";
			rs=db.execQuery(query, conn);
			while(rs.next())
			{
				corsi.add(
								new Corsi(
												rs.getInt("CodiceC"),rs.getString("NomeC"),
												rs.getString("DescrizioneVetrinaC"),rs.getString("ImmagineVetrinaC"),
												rs.getString("TitoloDescrizioneSinteticaC"),
												rs.getString("DescrizioneSinteticaC"), rs.getString("ImmagineDescrizioneC"),
												rs.getString("SpecificheC"), rs.getInt("NumEsamiC")
											)
							);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return corsi;
	}
	
	public ArrayList<Corsi> getCorsiDisabled() 
	{
		ArrayList<Corsi> corsi=new ArrayList<Corsi>();
		try
		{
			conn=SoftwareHouseDB.getConnection();
			String query="SELECT * FROM CORSO WHERE DISPONIBILE=false ORDER BY NUMESAMIC DESC;";
			rs=db.execQuery(query, conn);
			while(rs.next())
			{
				corsi.add(
								new Corsi(
												rs.getInt("CodiceC"),rs.getString("NomeC"),
												rs.getString("DescrizioneVetrinaC"),rs.getString("ImmagineVetrinaC"),
												rs.getString("TitoloDescrizioneSinteticaC"),
												rs.getString("DescrizioneSinteticaC"), rs.getString("ImmagineDescrizioneC"),
												rs.getString("SpecificheC"), rs.getInt("NumEsamiC")
											)
							);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return corsi;
	}
	
	public static Corsi findCorso(int codiceC) 
	{
		
		Corsi corsi=null;
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="SELECT * FROM CORSO WHERE CodiceC="+codiceC+";";
			rs=db.execQuery(query, conn);
			if(rs.next()) 
			{
				corsi= new Corsi	(
										rs.getInt("CodiceC"),rs.getString("NomeC"),
										rs.getString("DescrizioneVetrinaC"),rs.getString("ImmagineVetrinaC"),
										rs.getString("TitoloDescrizioneSinteticaC"),
										rs.getString("DescrizioneSinteticaC"), rs.getString("ImmagineDescrizioneC"),
										rs.getString("SpecificheC"), rs.getInt("NumEsamiC")
										
										);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return corsi;			
	}
	
	public int insertCorso(Corsi c)
	{
		int n=0;
		conn=SoftwareHouseDB.getConnection();
		String query="insert into corso (NomeC, DescrizioneVetrinaC, ImmagineVetrinaC, TitoloDescrizioneSinteticaC, DescrizioneSinteticaC, ImmagineDescrizioneC, SpecificheC, NUmEsamiC)" + 
						"values ('" + 
									c.getNomeC()+"','" + 
									c.getDescrizioneVetrinaC()+"','" + 
									c.getImmagineVetrinaC()+"','" + 
									c.getTitoloDescrizioneSinteticaC()+"','" + 
									c.getDescrizioneSinteticaC()+"','" +
									c.getImmagineDescrizioneC()+"','" +
									c.getSpecificheC()+"','" +
									c.getNumEsamiC()+
								"');";
		n=db.execUpdate(query, conn);
		SoftwareHouseDB.releaseConnection(conn);
		return n;	
	}
	
	public int disabilaCorso (int codiceC,String value)
	{
		int n;
		conn=SoftwareHouseDB.getConnection();
		String query="update corso set disponibile="+value+" where codiceC="+codiceC+";";		
		n=db.execUpdate(query, conn);	
		SoftwareHouseDB.releaseConnection(conn);
		return n;
	}
	
	public ArrayList<Corsi> getCorsi(String ricerca) 
	{
		ArrayList<Corsi> corsi=new ArrayList<Corsi>();
		try
		{
			conn=SoftwareHouseDB.getConnection();
			String query="SELECT * FROM corso WHERE disponibile=true AND (NomeC like '%"+ricerca+"%' OR TitoloDescrizioneSinteticaC like '%"+ricerca+"%' OR  DescrizioneSinteticaC like '%"+ricerca+"%' OR NomeC like '%"+ricerca+"%') ORDER BY NUMESAMIC DESC;";
			rs=db.execQuery(query, conn);
			while(rs.next())
			{
				corsi.add(
								new Corsi(
												rs.getInt("CodiceC"),rs.getString("NomeC"),
												rs.getString("DescrizioneVetrinaC"),rs.getString("ImmagineVetrinaC"),
												rs.getString("TitoloDescrizioneSinteticaC"),
												rs.getString("DescrizioneSinteticaC"), rs.getString("ImmagineDescrizioneC"),
												rs.getString("SpecificheC"), rs.getInt("NumEsamiC")
											)
							);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return corsi;
	}
}
