package model;

public class Pagamento
{
	private String numCarta;
	private String dataScadenza;
	
	public Pagamento(String numCarta, String dataScadenza) 
	{
		this.numCarta=numCarta;
		this.dataScadenza = dataScadenza;
	}
	public String getNumCarta() 
	{
		return numCarta;
	}

	public String getDataScadenza() 
	{
		return dataScadenza;
	}
	public void setDataScadenza(String dataScadenza) 
	{
		this.dataScadenza = dataScadenza;
	}
	
}
