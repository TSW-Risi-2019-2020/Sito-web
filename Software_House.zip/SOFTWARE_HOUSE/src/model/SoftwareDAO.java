package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import webSite.SoftwareHouseDB;

public class SoftwareDAO 
{
	private static Connection conn;
	private static ResultSet rs;
	private static SoftwareHouseDB db;
	
	//costruttore
	public SoftwareDAO()
	{
		conn=null;
		rs=null;
		db=SoftwareHouseDB.getDB();
	}
	
	//Software Singolo
	public static Software findSoftware(int codiceS) 
	{
		
		Software software=null;
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="SELECT * FROM SOFTWARE WHERE CodiceS="+codiceS+";";
			rs=db.execQuery(query, conn);
			if(rs.next()) 
			{
				software= new Software	(
											rs.getInt("CodiceS"),rs.getString("NomeS"),
											rs.getString("DescrizioneVetrinaS"),rs.getString("ImmagineVetrinaS"),
											rs.getString("DataRilascioS"),rs.getString("TitoloDescrizioneSinteticaS"),
											rs.getString("DescrizioneSinteticaS"), rs.getString("ImmagineDescrizioneS"),
											rs.getString("SpecificheS"), rs.getFloat("PrezzoS")
										);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return software;
				
	}
	//software
	public ArrayList<Software> getSoftware() 
	{
		ArrayList<Software> software=new ArrayList<Software>();
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="SELECT * FROM software WHERE disponibile=true ORDER BY DATARILASCIOS DESC;";
			rs=db.execQuery(query, conn);
			while(rs.next())
			{
				software.add(
								new Software	(
													rs.getInt("CodiceS"),rs.getString("NomeS"),
													rs.getString("DescrizioneVetrinaS"),rs.getString("ImmagineVetrinaS"),
													rs.getString("DataRilascioS"),rs.getString("TitoloDescrizioneSinteticaS"),
													rs.getString("DescrizioneSinteticaS"), rs.getString("ImmagineDescrizioneS"),
													rs.getString("SpecificheS"), rs.getFloat("PrezzoS")
												)
							);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return software;
	}
	
	public ArrayList<Software> getSoftwareDisabled() 
	{
		ArrayList<Software> software=new ArrayList<Software>();
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="SELECT * FROM software WHERE disponibile=false ORDER BY DATARILASCIOS DESC;";
			rs=db.execQuery(query, conn);
			while(rs.next())
			{
				software.add(
								new Software	(
													rs.getInt("CodiceS"),rs.getString("NomeS"),
													rs.getString("DescrizioneVetrinaS"),rs.getString("ImmagineVetrinaS"),
													rs.getString("DataRilascioS"),rs.getString("TitoloDescrizioneSinteticaS"),
													rs.getString("DescrizioneSinteticaS"), rs.getString("ImmagineDescrizioneS"),
													rs.getString("SpecificheS"), rs.getFloat("PrezzoS")
												)
							);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return software;
	}
	
	public int insertSoftware(Software s)
	{
		int n=0;
		conn=SoftwareHouseDB.getConnection();
		String query=	"insert into software (NomeS,DescrizioneVetrinaS, ImmagineVetrinaS, DataRilascioS, TitoloDescrizioneSinteticaS, DescrizioneSinteticaS, ImmagineDescrizioneS, SpecificheS, PrezzoS)" + 
						"values ('" + 
									s.getNomeS()+"','" + 
									s.getDescrizioneVetrinaS()+"','" + 
									s.getImmagineVetrinaS()+"','" + 
									s.getDataRilascioS()+"','" + 
									s.getTitoloDescrizioneSinteticaS()+"','" +
									s.getDescrizioneSinteticaS()+"','" +
									s.getImmagineDescrizioneS()+"','" +
									s.getSpecificheS()+"','" +
									s.getPrezzoS()+
								"');";
		n=db.execUpdate(query, conn);
		SoftwareHouseDB.releaseConnection(conn);
		return n;	
	}
	
	public int disabilaSoftware (int codiceS,String value)
	{
		int n;
		conn=SoftwareHouseDB.getConnection();
		String query="update software set disponibile="+value+" where codiceS="+codiceS+";";		
		n=db.execUpdate(query, conn);	
		SoftwareHouseDB.releaseConnection(conn);
		return n;
	}
	
	public ArrayList<Software> getSoftware(String ricerca) 
	{
		ArrayList<Software> software=new ArrayList<Software>();
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="SELECT * FROM software WHERE disponibile=true AND (TitoloDescrizioneSinteticaS like '%"+ricerca+"%' OR  DescrizioneSinteticaS like '%"+ricerca+"%' OR NomeS like '%"+ricerca+"%') ORDER BY DATARILASCIOS DESC;";
			rs=db.execQuery(query, conn);
			while(rs.next())
			{
				software.add(
								new Software	(
													rs.getInt("CodiceS"),rs.getString("NomeS"),
													rs.getString("DescrizioneVetrinaS"),rs.getString("ImmagineVetrinaS"),
													rs.getString("DataRilascioS"),rs.getString("TitoloDescrizioneSinteticaS"),
													rs.getString("DescrizioneSinteticaS"), rs.getString("ImmagineDescrizioneS"),
													rs.getString("SpecificheS"), rs.getFloat("PrezzoS")
												)
							);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return software;
	}
}
