package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import webSite.SoftwareHouseDB;

public class AcquistoDAO 
{
	private static Connection conn;
	private static ResultSet rs;
	private static SoftwareHouseDB db;
	
	//costruttore
	public AcquistoDAO()
	{
		conn=null;
		rs=null;
		db=SoftwareHouseDB.getDB();
	}
	public static ArrayList<Acquisto> getSoftwareAcquistati(String email) 
	{
		ArrayList<Acquisto> acquisti=new ArrayList<Acquisto>();
		conn=SoftwareHouseDB.getConnection();
		try
		{
			String query="select NomeS,CodiceS,Data_acquisto,prezzoS from software inner join acquista on CodiceS=Software_CodiceS where codiceS in (select Software_CodiceS from acquista where Cliente_EmailCL='"+email+"') and Cliente_EmailCL='"+email+"';";
			rs=db.execQuery(query, conn);
			while(rs.next())
			{
				acquisti.add(
								new Acquisto	(
													rs.getString("CodiceS"),rs.getString("Data_acquisto"),
													rs.getString("prezzoS"),rs.getString("NomeS")
												)
							);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			SoftwareHouseDB.releaseConnection(conn);
		}
		return acquisti;
	}
	

	public int insertAcquisto(String emailCL, int codiceS, String dataAcquisto)
	{
		int n=0;
		conn=SoftwareHouseDB.getConnection();
		String query=	"insert into acquista (Cliente_EmailCL, Software_CodiceS, Data_acquisto) "+ 
						"values ('" + 
									emailCL+"'," + 
									codiceS+",'" + 
									dataAcquisto+
								"');";
		n=db.execUpdate(query, conn);
		SoftwareHouseDB.releaseConnection(conn);
		return n;	
	}
}
