package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.SoftwareDAO;
import webSite.SoftwareHouseDB;

@WebServlet(name = "UpdateSoftware", urlPatterns = { "/UpdateSoftware" })
public class UpdateSoftware extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public UpdateSoftware() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		@SuppressWarnings("unused")
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		SoftwareDAO dao=new SoftwareDAO();
		String value="true";
		int codiceS;
		if(request.getParameter("deleteSoftware")!=null)
		{
			value="false";
			codiceS=Integer.parseInt(request.getParameter("deleteSoftware"));
		}
		else
			codiceS=Integer.parseInt(request.getParameter("addSoftware"));
		String message="";
		if(dao.disabilaSoftware(codiceS,value)>0)
			message="Modifica effettuata";
		else
			message="� stato riscontrato un problema durante l'esecuzione dell'operazione";
		request.setAttribute("message", message);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
		requestDispatcher.forward(request, response);
	}

}
