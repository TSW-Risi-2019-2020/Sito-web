package control;



import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import webSite.SoftwareHouseDB;


public class ServletListener implements ServletContextListener 
{
	
    public void contextInitialized(ServletContextEvent event) 
    {
    	 
    	ServletContext sc = event.getServletContext();
 
    	String url = sc.getInitParameter("url");
    	String username = sc.getInitParameter("username");
    	String password = sc.getInitParameter("password");
    	String database = sc.getInitParameter("database");
    	SoftwareHouseDB db = new SoftwareHouseDB(url+database,username,password);
    	
    	sc.setAttribute("SoftwareHouseDB", db);
 
    }
}
