package control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import model.ClienteDAO;

@WebServlet(name = "CheckParameter", urlPatterns = { "/CheckParameter" })
public class CheckParameter extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
   
    public CheckParameter() 
    {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
			JSONObject json=(JSONObject)JSONValue.parse(request.getParameter("email"));
			String email=(String) json.get("email");
			if(email!=null && !"".equals(email))
			{
				new ClienteDAO();
				if(ClienteDAO.findEmail(email))
				{
					response.setContentType("application/json");
				}
				else
					response.getWriter().write("null");
			}
			else
				response.getWriter().write("null");
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
