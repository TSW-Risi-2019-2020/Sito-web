package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Corsi;
import model.CorsoDAO;
import webSite.SoftwareHouseDB;
import webSite.Validate;


@WebServlet(name = "InsertCorso", urlPatterns = { "/InsertCorso" })
public class InsertCorso extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
  
    public InsertCorso() 
    {
        super();
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		@SuppressWarnings("unused")
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		CorsoDAO dao=new CorsoDAO();
		Corsi c=new Corsi(
									Validate.replaceString(request.getParameter("nomeCorso")),Validate.replaceString(request.getParameter("vetrinaC")),
									request.getParameter("immVetrina"),Validate.replaceString(request.getParameter("titolo")),
									Validate.replaceString(request.getParameter("sinteticaC")),request.getParameter("immDescrizione"),
									Validate.replaceString(request.getParameter("specificheC")),Integer.parseInt(request.getParameter("numEsami"))
								);
		String message="";
		if(dao.insertCorso(c)>0)
			message="Modifica effettuata";
		else
			message="� stato riscontrato un problema durante l'esecuzione dell'operazione";
		request.setAttribute("message", message);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
		requestDispatcher.forward(request, response);
	}

}
