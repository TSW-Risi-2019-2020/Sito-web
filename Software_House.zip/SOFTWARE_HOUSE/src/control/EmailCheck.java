package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Cliente;
import model.ClienteDAO;
import webSite.JavaMailUtil;
import webSite.JavaMailUtil.EmailType;
import webSite.SoftwareHouseDB;

@WebServlet(name = "EmailCheck", urlPatterns = { "/EmailCheck" })
	
public class EmailCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EmailCheck() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		@SuppressWarnings("unused")
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		new ClienteDAO();
		Cliente c=ClienteDAO.findCliente(request.getParameter("email"));
		if(c!=null)
		{	
			HttpSession session=request.getSession(true);
			session.setMaxInactiveInterval(10*60);
			String email=request.getParameter("email");
			String link = "https://127.0.0.1:443/SOFTWARE_HOUSE/ResetPassword?email="+email;
			JavaMailUtil.sendMail(email,link,EmailType.RICHIESTA_DI_SOSTITUZIONE);
			response.setStatus(HttpServletResponse.SC_ACCEPTED);
		}
		else
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("recover-password.jsp");
		requestDispatcher.forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
