package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Cliente;
import model.SegueDAO;
import webSite.SoftwareHouseDB;


@WebServlet(name = "RegistraEsame", urlPatterns = { "/RegistraEsame" })
public class RegistraEsame extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    
    public RegistraEsame() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		@SuppressWarnings("unused")
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		new SegueDAO();
		String message="";
		
		if(SegueDAO.updateSegue(Integer.parseInt(request.getParameter("codiceEsame")), ((Cliente)request.getSession().getAttribute("utente")).getEmailCL()))
		{
			message="L'esame � stato aggiunto correttamente al libretto";
			HttpSession session=request.getSession(false);
			session.removeAttribute("corsiSeguiti");
			session.setAttribute("corsiSeguiti", SegueDAO.getCorsiSeguiti(((Cliente)request.getSession().getAttribute("utente")).getEmailCL()));
		}
		else
			message="E' stato riscontrato un problema durante la registrazione";
		
		request.setAttribute("message", message);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
		requestDispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
