package control;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Acquisto;
import model.AcquistoDAO;
import model.Cliente;
import model.ClienteDAO;
import model.Pagamento;
import model.PagamentoDAO;
import model.Segue;
import model.SegueDAO;
import webSite.SoftwareHouseDB;

@WebServlet(name = "SignIn", urlPatterns = { "/SignIn" })
public class SignIn extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
     
    public SignIn() 
    {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		@SuppressWarnings("unused")
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		new ClienteDAO();
		new AcquistoDAO();
		new SegueDAO();
		new PagamentoDAO();
		Cliente cliente=ClienteDAO.findCliente(request.getParameter("j_username"),request.getParameter("j_password"));
		if(cliente==null)
		{
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			RequestDispatcher rdd=request.getRequestDispatcher("/login.jsp");
			rdd.forward(request, response);
			return;
		}
		ArrayList<Pagamento> carte=PagamentoDAO.getCarte(cliente.getEmailCL());
		ArrayList<Acquisto> softwareAcquistati=AcquistoDAO.getSoftwareAcquistati(cliente.getEmailCL());
		ArrayList<Segue> corsiSeguiti=SegueDAO.getCorsiSeguiti(cliente.getEmailCL());
		HttpSession session=request.getSession(true);
		session.setAttribute("carte", carte);
		session.setAttribute("utente", cliente);
		session.setAttribute("softwareAcquistati", softwareAcquistati);
		session.setAttribute("corsiSeguiti", corsiSeguiti);
		session.setMaxInactiveInterval(10*60);
		response.sendRedirect("j_security_check?j_username="+request.getParameter("j_username")+"&j_password="+request.getParameter("j_password"));
	}

}
