package control;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Acquisto;
import model.Carrello;
import webSite.SoftwareHouseDB;


@WebServlet(name = "Checkout", urlPatterns = { "/Checkout" })
public class Checkout extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
    public Checkout() 
    {
        super();
    }

	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		@SuppressWarnings("unused")
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		HttpSession session=request.getSession(false);
		ArrayList<Carrello> carrello=(ArrayList<Carrello>)session.getAttribute("carrello");
		ArrayList<Acquisto> softwareAcquistati=(ArrayList<Acquisto>)session.getAttribute("softwareAcquistati");
		ArrayList<Integer> array=new ArrayList<Integer>();
		
		if(carrello==null || carrello.size()==0)
		{
			String message="Non � stato inserito nessun elemento nel carrello";
			request.setAttribute("message", message);
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
			requestDispatcher.forward(request, response);
			return;
		}
		
		for(int i=0;i<carrello.size();i++)
			for(Acquisto a: softwareAcquistati)
				if(carrello.get(i).getCodiceS()==Integer.parseInt(a.getCodiceS()))
					array.add(i);
		
		for(int j=array.size()-1;j>=0;j--)
			carrello.remove((int)array.get(j));
		
		session.removeAttribute("carrello");
		session.setAttribute("carrello", carrello);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("checkout.jsp");
		requestDispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
