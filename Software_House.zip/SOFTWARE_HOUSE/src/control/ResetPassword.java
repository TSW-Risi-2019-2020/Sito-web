package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Cliente;
import model.ClienteDAO;
import webSite.JavaMailUtil;
import webSite.JavaMailUtil.EmailType;
import webSite.SoftwareHouseDB;

@WebServlet(name = "ResetPassword", urlPatterns = { "/ResetPassword" })
public class ResetPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ResetPassword() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
    	@SuppressWarnings("unused")
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		String message="� stato riscontrato un problema durante l'esecuzione dell'operazione";
		String email=request.getParameter("email");
		new ClienteDAO();
		Cliente c=ClienteDAO.findCliente(email);
		if(c!=null)
		{
			String password=JavaMailUtil.generatorRandomPassword();
			ClienteDAO dao=new ClienteDAO();
			int n=dao.updatePassword(email, password);
			if(n>0)
			{
				JavaMailUtil.sendMail(email, password, EmailType.NUOVA_PASSWORD);
				message="Ti � stata inviata una nuova password controlla l'idirizzo di posta elettronica";
			}
			request.setAttribute("message", message);
			RequestDispatcher rd=request.getRequestDispatcher("/message.jsp");
			rd.forward(request, response);
			return;
		}
		request.setAttribute("message", message);
		RequestDispatcher rd=request.getRequestDispatcher("/message.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}

}
