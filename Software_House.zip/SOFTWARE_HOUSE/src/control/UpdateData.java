package control;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Cliente;
import model.Pagamento;
import model.PagamentoDAO;
import webSite.SoftwareHouseDB;


@WebServlet(name = "UpdateData", urlPatterns = { "/UpdateData" })
public class UpdateData extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
    public UpdateData() 
    {
        super();
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		@SuppressWarnings("unused")
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		PagamentoDAO dao=new PagamentoDAO();
		HttpSession session=request.getSession(false);
		Cliente cliente=(Cliente) session.getAttribute("utente");
		if(dao.insertPagamento(request.getParameter("numero"),request.getParameter("data") , cliente.getEmailCL() , request.getParameter("codice"))==0)
		{
			String message="� stato riscontrato un problema durante l'esecuzione dell'operazione";
			request.setAttribute("message", message);
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
			requestDispatcher.forward(request, response);
			return;
		}
		session.removeAttribute("carte");
		ArrayList<Pagamento> carte=PagamentoDAO.getCarte(cliente.getEmailCL());
		session.setAttribute("carte", carte);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("personalarea.jsp");
		requestDispatcher.forward(request, response);
	}

}
