package control;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Software;
import model.SoftwareDAO;
import webSite.SoftwareHouseDB;

@WebServlet(name = "SoftwareList", urlPatterns = { "/SoftwareList" })
public class SoftwareList extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    public SoftwareList() 
    {
        super();
    }
    

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		@SuppressWarnings("unused")
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		ArrayList<Software> software=new ArrayList<Software>();
		SoftwareDAO s=new SoftwareDAO();
		String text;
		
		if(request.getParameter("ricercaSoftware")==null)
		{
			software=s.getSoftware();	
			text="SOFTWARE RECENTI";
		}
		else
		{
			software=s.getSoftware(request.getParameter("ricercaSoftware"));
			text="RISULTATO RICERCA";
		}
		
		request.setAttribute("text", text);
		request.setAttribute("software",software);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("software.jsp");
		requestDispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}