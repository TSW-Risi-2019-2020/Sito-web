package control;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Carrello;

@WebServlet(name = "RemoveCart", urlPatterns = { "/RemoveCart" })
public class RemoveCart extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
  
    public RemoveCart() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int codice=Integer.parseInt(request.getParameter("CodiceS"));
		HttpSession session=request.getSession(false);
		
		@SuppressWarnings("unchecked")
		ArrayList<Carrello> carrello=(ArrayList<Carrello>)session.getAttribute("carrello");
		for(int i=0;i<carrello.size();i++)
		{
			if(carrello.get(i).getCodiceS()==codice)
				carrello.remove(i);
		}
		session.removeAttribute("carrello");
		session.setAttribute("carrello", carrello);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("carrello.jsp");
		requestDispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}

}
