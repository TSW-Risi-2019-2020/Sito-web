package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Cliente;
import model.ClienteDAO;
import webSite.SoftwareHouseDB;


@WebServlet(name = "UpdatePersonalData", urlPatterns = { "/UpdatePersonalData" })
public class UpdatePersonalData extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
    public UpdatePersonalData() 
    {
        super();
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		@SuppressWarnings("unused")
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		ClienteDAO dao=new ClienteDAO();
		HttpSession session=request.getSession(false);
		Cliente cliente=(Cliente) session.getAttribute("utente");
		if(dao.updateCliente(request.getParameter("username"), cliente.getEmailCL(), request.getParameter("password"))==0)
		{
			String message="� stato riscontrato un problema durante l'esecuzione dell'operazione";
			request.setAttribute("message", message);
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
			requestDispatcher.forward(request, response);
			return;
		}
		session.removeAttribute("utente");
		Cliente cliente2=ClienteDAO.findCliente(cliente.getEmailCL(), request.getParameter("password"));
		session.setAttribute("utente", cliente2);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("personalarea.jsp");
		requestDispatcher.forward(request, response);
	}

}
