package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Software;
import model.SoftwareDAO;
import webSite.SoftwareHouseDB;
import webSite.Validate;


@WebServlet(name = "InsertSoftware", urlPatterns = { "/InsertSoftware" })
public class InsertSoftware extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
  
    public InsertSoftware() 
    {
        super();
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		@SuppressWarnings("unused")
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		SoftwareDAO dao=new SoftwareDAO();
		Software s=new Software (
									Validate.replaceString(request.getParameter("nomeSoftware")),Validate.replaceString(request.getParameter("descrizioneV")),
									request.getParameter("immVetrina"),request.getParameter("data"),
									Validate.replaceString(request.getParameter("titolo")),Validate.replaceString(request.getParameter("descrizioneS")),
									request.getParameter("immDescrizione"),Validate.replaceString(request.getParameter("specifiche")),
									Float.parseFloat(request.getParameter("prezzo"))
								);
		String message="";
		if(dao.insertSoftware(s)>0)
			message="Modifica effettuata";
		else
			message="� stato riscontrato un problema durante l'esecuzione dell'operazione";
		request.setAttribute("message", message);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
		requestDispatcher.forward(request, response);
	}

}
