package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Cliente;
import model.ClienteDAO;
import webSite.SoftwareHouseDB;
import webSite.Validate;

@WebServlet(name = "SignUpServlet", urlPatterns = { "/SignUpServlet" })
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public SignUpServlet() 
    {
        super();
    }
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		@SuppressWarnings("unused")
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		Cliente c=null;
		
		if(request.getParameter("Tipo")==null)
			c=new Cliente	(
								"S",
								request.getParameter("username"),Validate.replaceString(request.getParameter("nome")),
								Validate.replaceString(request.getParameter("cognome")),request.getParameter("data"), 
								Validate.replaceString(request.getParameter("indirizzo")), request.getParameter("email"), 
								request.getParameter("password")
							);
		ClienteDAO dao=new ClienteDAO();
		String message="";
		if(dao.insertCliente(c)>0)
			message="Registrazione avvenuta con successo";
		else
			message="Abbiamo rilevato un problema durante la registrazione:(";
		request.setAttribute("message", message);
		RequestDispatcher rd=request.getRequestDispatcher("/message.jsp");
		rd.forward(request, response);
	}
}
