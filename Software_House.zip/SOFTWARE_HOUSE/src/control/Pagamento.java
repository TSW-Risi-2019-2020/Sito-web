package control;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.AcquistoDAO;
import model.Carrello;
import model.Cliente;
import model.PagamentoDAO;
import webSite.SoftwareHouseDB;



@WebServlet(name = "Pagamento", urlPatterns = { "/Pagamento" })
public class Pagamento extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
   
    public Pagamento() 
    {
        super();
    }

	@SuppressWarnings("unused")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		HttpSession session=request.getSession(false);
		String message="";
		new PagamentoDAO();
		if(session!=null && PagamentoDAO.CheckCarta(request.getParameter("numero"), request.getParameter("codice"), ((Cliente)request.getSession().getAttribute("utente")).getEmailCL()))
		{
			String numero=request.getParameter("numero");
			String intestatario=request.getParameter("intestatario");
			String dataScadenza=request.getParameter("dataScadenza");
			String codice=request.getParameter("codice"); 
			
				/* SIMULAZIONE DEL PAGAMENTO */
			
			GregorianCalendar gc = new GregorianCalendar();
			int giorno=gc.get(Calendar.DAY_OF_MONTH);
			int mese=gc.get(Calendar.MONTH)+1;
			int anno=gc.get(Calendar.YEAR);
			
			Cliente cliente=(Cliente)session.getAttribute("utente");
			@SuppressWarnings("unchecked")
			ArrayList<Carrello> carrello=(ArrayList<Carrello>)session.getAttribute("carrello");
			AcquistoDAO dao=new AcquistoDAO();
			
			for(Carrello c: carrello)
				dao.insertAcquisto(cliente.getEmailCL(), c.getCodiceS(), anno+"-"+mese+"-"+giorno);
			
			
			message="L'acquisto � avvenuto con successo!";
			session.removeAttribute("softwareAcquistati");
			session.removeAttribute("carrello");
			session.setAttribute("softwareAcquistati", AcquistoDAO.getSoftwareAcquistati(cliente.getEmailCL()));
		}
		
		else
			message="E' stato riscontrato un problema durante l'acquisto :(";
		request.setAttribute("message", message);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
		requestDispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
