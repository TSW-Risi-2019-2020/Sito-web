package control;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Corsi;
import model.CorsoDAO;
import webSite.SoftwareHouseDB;


@WebServlet(name = "CoursesList", urlPatterns = { "/CoursesList" })
public class CoursesList extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public CoursesList() 
    {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		@SuppressWarnings("unused")
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		ArrayList<Corsi> corsi=new ArrayList<Corsi>();
		CorsoDAO dao=new CorsoDAO();	
		String text;
		
		if(request.getParameter("ricercaCorsi")==null)
		{
			corsi=dao.getCorsi();	
			text="CORSI RAPIDI";
		}
		else
		{
			corsi=dao.getCorsi(request.getParameter("ricercaCorsi"));
			text="RISULTATO RICERCA";
		}
		
		request.setAttribute("text", text);
		request.setAttribute("corsi",corsi);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("formazione.jsp");
		requestDispatcher.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
