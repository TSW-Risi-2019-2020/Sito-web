package control;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Cliente;
import model.Segue;
import model.SegueDAO;
import webSite.SoftwareHouseDB;


@WebServlet(name = "InsertSegue", urlPatterns = { "/InsertSegue" })
public class InsertSegue extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
   
    public InsertSegue() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		@SuppressWarnings("unused")
		SoftwareHouseDB db = (SoftwareHouseDB) getServletContext().getAttribute("SoftwareHouseDB");
		HttpSession session=request.getSession(false);
		
		SegueDAO dao=new SegueDAO();
			
		GregorianCalendar gc = new GregorianCalendar();
		int giorno=gc.get(Calendar.DAY_OF_MONTH);
		int mese=gc.get(Calendar.MONTH)+1;
		int anno=gc.get(Calendar.YEAR);
		
		Cliente c=(Cliente)session.getAttribute("utente");
		
		dao.insertSegue(anno+"-"+mese+"-"+giorno, c.getEmailCL(), Integer.parseInt(request.getParameter("CodiceC")));
		
		String message="Iscrizione avvenuta con successo!";
		request.setAttribute("message", message);
		
		session.removeAttribute("corsiSeguiti");
		ArrayList<Segue> corsiSeguiti=SegueDAO.getCorsiSeguiti(c.getEmailCL());
		session.setAttribute("corsiSeguiti", corsiSeguiti);
		
		RequestDispatcher rdd = request.getRequestDispatcher("message.jsp");
		rdd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}

