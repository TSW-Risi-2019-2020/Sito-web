package control;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Carrello;
import model.Cliente;
import webSite.Validate;


@WebServlet(name = "InsertCart", urlPatterns = { "/InsertCart" })
public class InsertCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public InsertCart() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession(false);
		
		Cliente cliente=(Cliente)session.getAttribute("utente");
			
		Carrello c=new Carrello (
									cliente.getEmailCL(), Integer.parseInt(request.getParameter("CodiceS")), 
									Validate.replaceString(request.getParameter("NomeS")), Float.parseFloat(request.getParameter("PrezzoS"))
								);
			
		@SuppressWarnings("unchecked")
		ArrayList<Carrello> carrello=(ArrayList<Carrello>)session.getAttribute("carrello");
		String message="";
		if(carrello==null)
		{
			carrello=new ArrayList<Carrello>();
			carrello.add(c);
			message="Il software selezionato � stato aggiunto correttamente al carrello";
		}
		else
		{
			if(carrello.contains(c))
				message="E' stato riscontrato un problema durante l'operazione";
			else
			{
				carrello.add(c);
				message="Il software selezionato � stato aggiunto correttamente al carrello";
			}
				
		}
		session.removeAttribute("carrello");
		session.setAttribute("carrello", carrello);
		request.setAttribute("message", message);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
		requestDispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
