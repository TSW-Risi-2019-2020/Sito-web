package webSite;

public class Validate 
{
	public static String replaceString (String s)
	{
		return s.replace("'", "\\'");
	}
}
