package webSite;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.TimeZone;
import utilities.Corsi;

public class SoftwareHouseDB 
{
	private PreparedStatement pst=null;
	private Connection conn=null;
	private ResultSet rs=null;
	private static List<Connection> freeDbConnections;
	
	public SoftwareHouseDB() 
	{
		try 
		{
			freeDbConnections=new LinkedList<Connection>();	
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
	}
	
	public static Connection createDBConnection() 
	{
		try
		{
			String url="jdbc:mysql://localhost:3306/JFLCorporation";
			Connection conn=DriverManager.getConnection(url+"?serverTimezone="+TimeZone.getDefault().getID(),"StandardUser","Password1");
			conn.setAutoCommit(false);
			return conn;
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static synchronized Connection getConnection() 
	{
		Connection connection;

		if (!freeDbConnections.isEmpty())
		{
			connection = freeDbConnections.get(0);
			SoftwareHouseDB.freeDbConnections.remove(0);
			try
			{
				if (connection.isClosed())
					connection = SoftwareHouseDB.getConnection();
			} 
			catch (SQLException e)
			{
				try
				{
					if (connection != null) 
					{
						connection.close();
						connection=null;
					}
				}
				catch(SQLException e1) 
				{
					System.out.println(e1.getMessage());
				}
				connection = SoftwareHouseDB.getConnection();
				e.printStackTrace();
			}
		} 
		else 
		{
			connection = createDBConnection();
		}
		return connection;
	}
	
	public static synchronized void releaseConnection(Connection connection)
	{
		try 
		{
			connection.commit();
			SoftwareHouseDB.freeDbConnections.add(connection);
		} 
		catch (SQLException e) 
		{
			System.err.println(e.getMessage());
		}
	}
	
	public ResultSet execQuery(String query, Connection conn) 
	{
		try 
		{
			pst=conn.prepareStatement(query);
			rs=pst.executeQuery();
			return rs;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public int execUpdate(String query, Connection conn)
	{
		try 
		{
			int n;
			pst=conn.prepareStatement(query);
			n=pst.executeUpdate();
			pst.close();
			return n;
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return 0;
		}
	}
	
	
	
	//corsi
	public ArrayList<Corsi> getCorsi() 
	{
		ArrayList<Corsi> corsi=new ArrayList<Corsi>();
		try
		{
			conn=getConnection();
			String query="SELECT * FROM CORSO ORDER BY NUMESAMIC DESC;";
			execQuery(query, conn);
			while(rs.next())
			{
				corsi.add(
								new Corsi(
												rs.getInt("CodiceC"),rs.getString("NomeC"),
												rs.getString("DescrizioneVetrinaC"),rs.getString("ImmagineVetrinaC"),
												rs.getString("TitoloDescrizioneSinteticaC"),
												rs.getString("DescrizioneSinteticaC"), rs.getString("ImmagineDescrizioneC"),
												rs.getString("SpecificheC"), rs.getInt("NumEsamiC")
											)
							);
			}
			rs.close();
			pst.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			releaseConnection(conn);
		}
		return corsi;
	}
	
	
	
}
