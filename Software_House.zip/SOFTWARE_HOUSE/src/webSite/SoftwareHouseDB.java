package webSite;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.LinkedList;
import java.util.List;
import java.util.TimeZone;



public class SoftwareHouseDB 
{
	public static String url;
	public static String username;
	public static String password;
	private PreparedStatement pst=null;

	private ResultSet rs=null;
	private static SoftwareHouseDB db;
	private static List<Connection> freeDbConnections;
	
	static 
	{		
		freeDbConnections=new LinkedList<Connection>();	
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
	}
	
	public SoftwareHouseDB(String url,String username,String password) 
	{
		SoftwareHouseDB.url=url;
		SoftwareHouseDB.username=username;
		SoftwareHouseDB.password=password;
		db=this;
	}
	
	public static SoftwareHouseDB getDB() 
	{
		return db;
	}
	
	private static Connection createDBConnection() 
	{
		try
		{
			Connection conn=DriverManager.getConnection(url+"?serverTimezone="+TimeZone.getDefault().getID(),username,password);
			conn.setAutoCommit(false);
			return conn;
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static synchronized Connection getConnection() 
	{
		Connection connection;

		if (!freeDbConnections.isEmpty())
		{
			connection = freeDbConnections.get(0);
			SoftwareHouseDB.freeDbConnections.remove(0);
			try
			{
				if (connection.isClosed())
					connection = SoftwareHouseDB.getConnection();
			} 
			catch (SQLException e)
			{
				try
				{
					if (connection != null) 
					{
						connection.close();
						connection=null;
					}
				}
				catch(SQLException e1) 
				{
					System.out.println(e1.getMessage());
				}
				connection = SoftwareHouseDB.getConnection();
				e.printStackTrace();
			}
		} 
		else 
		{
			connection = createDBConnection();
		}
		return connection;
	}
	
	public static synchronized void releaseConnection(Connection connection)
	{
		try 
		{
			connection.commit();
			SoftwareHouseDB.freeDbConnections.add(connection);
		} 
		catch (SQLException e) 
		{
			System.err.println(e.getMessage());
		}
	}
	
	public ResultSet execQuery(String query, Connection conn) 
	{
		try 
		{
			pst=conn.prepareStatement(query);
			rs=pst.executeQuery();
			return rs;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public int execUpdate(String query, Connection conn)
	{
		try 
		{
			int n;
			pst=conn.prepareStatement(query);
			n=pst.executeUpdate();
			pst.close();
			return n;
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return 0;
		}
	}
	
	
}
