package webSite;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.TimeZone;

import utilities.Corsi;
import utilities.Software;

public class SoftwareHouseDB 
{
	private PreparedStatement pst=null;
	private Connection conn=null;
	private ResultSet rs=null;
	private static List<Connection> freeDbConnections;
	
	public SoftwareHouseDB() 
	{
		try 
		{
			freeDbConnections=new LinkedList<Connection>();	
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
	}
	
	public static Connection createDBConnection() 
	{
		try
		{
			String url="jdbc:mysql://localhost:3306/JFLCorporation";
			Connection conn=DriverManager.getConnection(url+"?serverTimezone="+TimeZone.getDefault().getID(),"StandardUser","Password1");
			conn.setAutoCommit(false);
			return conn;
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static synchronized Connection getConnection() 
	{
		Connection connection;

		if (!freeDbConnections.isEmpty())
		{
			connection = freeDbConnections.get(0);
			SoftwareHouseDB.freeDbConnections.remove(0);
			try
			{
				if (connection.isClosed())
					connection = SoftwareHouseDB.getConnection();
			} 
			catch (SQLException e)
			{
				try
				{
					if (connection != null) 
					{
						connection.close();
						connection=null;
					}
				}
				catch(SQLException e1) 
				{
					System.out.println(e1.getMessage());
				}
				connection = SoftwareHouseDB.getConnection();
				e.printStackTrace();
			}
		} 
		else 
		{
			connection = createDBConnection();
		}
		return connection;
	}
	
	public static synchronized void releaseConnection(Connection connection)
	{
		try 
		{
			connection.commit();
			SoftwareHouseDB.freeDbConnections.add(connection);
		} 
		catch (SQLException e) 
		{
			System.err.println(e.getMessage());
		}
	}
	
	private void execQuery(String query) 
	{
		try 
		{
			pst=conn.prepareStatement(query);
			rs=pst.executeQuery();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	
	//software
	public ArrayList<Software> getSoftware() 
	{
		ArrayList<Software> software=new ArrayList<Software>();
		try
		{
			conn=getConnection();
			String query="SELECT * FROM SOFTWARE ORDER BY DATARILASCIOS DESC;";
			execQuery(query);
			while(rs.next())
			{
				software.add(
								new Software(
												rs.getInt("CodiceS"),rs.getString("NomeS"),
												rs.getString("DescrizioneVetrinaS"),rs.getString("ImmagineVetrinaS"),
												rs.getString("DataRilascioS"),rs.getString("TitoloDescrizioneSinteticaS"),
												rs.getString("DescrizioneSinteticaS"), rs.getString("ImmagineDescrizioneS"),
												rs.getString("SpecificheS"), rs.getFloat("PrezzoS")
											)
							);
			}
			rs.close();
			pst.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			releaseConnection(conn);
		}
		return software;
	}
	
	
	//corsi
	public ArrayList<Corsi> getCorsi() 
	{
		ArrayList<Corsi> corsi=new ArrayList<Corsi>();
		try
		{
			conn=getConnection();
			String query="SELECT * FROM CORSO ORDER BY NUMESAMIC DESC;";
			execQuery(query);
			while(rs.next())
			{
				corsi.add(
								new Corsi(
												rs.getInt("CodiceC"),rs.getString("NomeC"),
												rs.getString("DescrizioneVetrinaC"),rs.getString("ImmagineVetrinaC"),
												rs.getString("TitoloDescrizioneSinteticaC"),
												rs.getString("DescrizioneSinteticaC"), rs.getString("ImmagineDescrizioneC"),
												rs.getString("SpecificheC"), rs.getInt("NumEsamiC")
											)
							);
			}
			rs.close();
			pst.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			releaseConnection(conn);
		}
		return corsi;
	}
	
	//metodo che restituisce un singolo software
	public Software getS(int codiceS) 
	{
		Software s=null;
		try
		{
			conn=getConnection();
			String query="select CodiceS, NomeS, DataRilascioS,TitoloDescrizioneSinteticaS,ImmagineDescrizioneS,SpecificheS,PrezzoS from software where CodiceS="+codiceS+";";
			execQuery(query);
			if(rs.next())
			{
				s=new Software	(
									rs.getInt("CodiceS"), rs.getString("NomeS"),
									rs.getString("DataRilascioS"),  rs.getString("ImmagineDescrizioneS"), 
									rs.getString("SpecificheS"), rs.getFloat("PrezzoS")
								);
			}
			rs.close();
			pst.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			releaseConnection(conn);
		}
		return s;
	}
	
	
	
}
