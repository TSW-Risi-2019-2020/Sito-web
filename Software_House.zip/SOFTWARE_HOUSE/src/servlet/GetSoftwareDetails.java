package servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.*;
import utilities.Software;
import webSite.SoftwareHouseDB;

@WebServlet(name = "GetSoftwareDetails", urlPatterns = { "/GetSoftwareDetails" })
public class GetSoftwareDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public GetSoftwareDetails() 
    {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.getWriter().append("Served at: ").append(request.getContextPath());
		SoftwareHouseDB db=new SoftwareHouseDB();
		Software s=db.getS(Integer.parseInt(request.getParameter("fragment")));
		response.setHeader("Software", s.toString());
		String docType="<!doctype html public \"-//w3c//dtd html 4.0 " + "transitional//en\">\n";
				
		PrintWriter out = response.getWriter();
		out.println(docType+"<div class=\"col-md-8 col-sm-8 col-xs-12\">"+
        "<div class=\"row\">"+
          "<div class=\"col-md-12 col-sm-12 col-xs-12\">"+
            "<article class=\"blog-post-wrapper\">"+
              "<div class=\"post-thumbnail\">"+
                "<img src=\"\" alt=\"immagine-software-details\" />"+
              "</div>"+
              "<div class=\"post-information\">"+
                "<h2>Specifiche complete del software</h2>"+
                "<div class=\"entry-meta\">"+
                  "<span><i class=\"fa fa-clock-o\"></i> DATA SOFTWARE</span>"+
                "</div>"+
                "<div class=\"entry-content\">"+
                  "<p>SPECIFICHE SOFTWARE</p>"+					
						"<a href=\"#\" data-toggle=\"modal\" data-target=\"#modal_buy\" class=\"btn btn-lg btn-primary btn-rounded\">ACQUISTA ORA</a>"+
                "</div>"+
              "</div>"+
            "</article>"+
            "<div class=\"clear\"></div>"+
          "</div>"+
        "</div>"+
      "</div>");
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
