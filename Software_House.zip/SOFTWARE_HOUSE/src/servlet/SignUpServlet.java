package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utilities.Cliente;
import utilities.ClienteDAO;

@WebServlet(name = "SignUpServlet", urlPatterns = { "/SignUpServlet" })
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public SignUpServlet() 
    {
        super();
    }
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Cliente c=new Cliente(
								request.getParameter("username"),request.getParameter("nome"),
								request.getParameter("cognome"),request.getParameter("data"), 
								request.getParameter("indirizzo"), request.getParameter("email"), request.getParameter("password")
								
							);
		ClienteDAO db=new ClienteDAO();
		int n=db.insertCliente(c);
		
		if(n==1)
			response.setStatus(HttpServletResponse.SC_CREATED);
		else
			response.setStatus(HttpServletResponse.SC_CONFLICT);
		RequestDispatcher rd=request.getRequestDispatcher("/registrazione.jsp");
		rd.forward(request, response);
	}
	

}
