function Accesso()
{
	
}