var x=true;
function checkName(inputtxt){

	var name=/^[A-Za-z0-9 _\']{3,20}$/;
	if(inputtxt.value.match(name)){
		return true;
	}else{
		alert("Nome o Cognome non validi");
		inputtxt.focus();
		return false;
	}
}
function checkEmail(inputtxt){
	var email=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(inputtxt.value.match(email)){
		return true;
	}else{
		alert("Email non valida");
		inputtxt.focus();
		return false;
	}
}
function checkPassword(inputtxt){
	var password=/^[A-Za-z0-9]{8,20}$/;
	if(inputtxt.value.match(password)){
		return true;
	}else{
		alert("Password non valida");
		inputtxt.focus();
		return false;
	}
}

function checkNascita(inputtxt){
	var data=/^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$/;
	if(inputtxt.value.match(data)){
		return true;
	}else{
		alert("Data di nascita non valida");
		inputtxt.focus();
		return false;
	}
}

function checkIndirizzo(inputtxt)
{
	var indirizzo=/^[a-zA-Z0-9',./ \/\s]*$/;
	if(inputtxt.value.match(indirizzo)){
		return true;
	}else{
		alert("Indirizzo non valido");
		inputtxt.focus();
		return false;
	}
}
function checkUsername(inputtxt){
	var username=/^[A-Za-z0-9\s]{3,20}$/;
	if(inputtxt.value.match(username)){
		return true;
	}else{
		alert("Username non valido");
		inputtxt.focus();
		return false;
	}
}

function checkCarta(inputtxt){
	var carta=/^^[0-9]{16}$/;
	if(inputtxt.value.match(carta)){
		return true;
	}else{
		alert("Carta non valida");
		inputtxt.focus();
		return false;
	}
}
function checkDataCarta(inputtxt){
	var data=/^\d{2}[\/\-](0?[1-9]|1[012])$/;
	if(inputtxt.value.match(data)){
		return true;
	}else{
		alert("Data di scadenza non valida");
		inputtxt.focus();
		return false;
	}
}

function checkCVC(inputtxt){
	var CVC=/^[0-9]{3}$/;
	if(inputtxt.value.match(CVC)){
		return true;
	}else{
		alert("Codice CVC non valido");
		inputtxt.focus();
		return false;
	}
	
}

function checkNomeSoftware(inputtxt){
	var software=/^[A-Za-z0-9'_-\s]*$/;
	if(inputtxt.value.match(software)){
		return true;
	}else{
		alert("Nome del software non valido");
		inputtxt.focus();
		return false;
	}
	
}

function checkImmagineVetrina(inputtxt){
	var img=/^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;
	if(inputtxt.value.match(img)){
		return true;
	}else{
		alert("Immagine Vetrina non valida");
		inputtxt.focus();
		return false;
	}
	
}

function checkDataDiRilascio(inputtxt){
	var data=/^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$/;
	if(inputtxt.value.match(data)){
		return true;
	}else{
		alert("Data di rilascio del software non valida");
		inputtxt.focus();
		return false;
	}
}

function checkTitolo(inputtxt){
	var titolo=/^[A-Za-z0-9',._-\s]*$/;
	if(inputtxt.value.match(titolo)){
		return true;
	}else{
		alert("Titolo non valido");
		inputtxt.focus();
		return false;
	}
}
function checkImmagineDescrizione(inputtxt){
	var img=/^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;
	if(inputtxt.value.match(img)){
		return true;
	}else{
		alert("Immagine Descrizione non valida");
		inputtxt.focus();
		return false;
	}
}
function checkPrezzo(inputtxt){
	var prezzo=/^[0-9]+(\.\d{1,2})?$/;
	if(inputtxt.value.match(prezzo)){
		return true;
	}else{
		alert("Prezzo non valido");
		inputtxt.focus();
		return false;
	}
}
function checkDescrizione(inputtxt){
	var descrizione=/^[A-Za-z0-9',.àèùò\s]*$/;
	if(inputtxt.value.match(descrizione)){
		return true;
	}else{
		alert("Descrizione non valida");
		inputtxt.focus();
		return false;
	}
}
function checkNumeroEsami(inputtxt){
	var numEsami=/^\d*$/;
	if(inputtxt.value.match(numEsami)){
		return true;
	}else{
		alert("Il numero di esami non \u00E8 valido");
		inputtxt.focus();
		return false;
	}
	
}


function validate(){
	console.log("Parte");
	var username=document.getElementById("username");
	var name= document.getElementById("name");
	var surname= document.getElementById("surname");
	var email= document.getElementById("email");
	var data= document.getElementById("data");
	var indirizzo= document.getElementById("indirizzo");		
	var password= document.getElementById("password");
	var conferma= document.getElementById("conferma");

	if(checkUsername(username)){
		if(checkName(name)){
			if(checkName(surname)){
				if(checkEmail(email)){
					if(checkNascita(data)){
						if(checkIndirizzo(indirizzo)){
							if(checkPassword(password)){
								if(checkPassword(conferma)){
									if(!(password.value==conferma.value)){
										alert("Le password non corrispondono");
										conferma.focus();
										return false;
									}else
									document.getElementById("myForm").submit();
								}
							}
						}
					}
				}
			}
		}
	}
	return false;
}

function validateLogin(){
	var email= document.getElementById("email2");
	var password= document.getElementById("password2");
	if(checkEmail(email)){
		if(checkPassword(password)){
		}
	}
	return false;

}

function validateDatiPersonali(){

	var username= document.getElementById("username");
	var password= document.getElementById("password");
	var conferma= document.getElementById("conferma");
	if(checkUsername(username)){
		if(checkPassword(password)){
			if(checkPassword(conferma)){
				if(!(password.value==conferma.value)){
					alert("Le password non corrispondono");
					conferma.focus();
					return false;
				}else{
					document.getElementById("submit").submit();
				}
			}
		}
	}
	return false;
}


function validatePagamento(){
	var numero= document.getElementById("numero");
	var data= document.getElementById("data");
	var CVC= document.getElementById("CVC");
	if(checkCarta(numero)){
		if(checkDataCarta(data)){
			if(checkCVC(CVC)){
				document.getElementById("submit2").submit();
			}
		}
	}
	return false;
}

function validateAggiungiSoftware(){

	var software=document.getElementById("software");
	var imgVetrina=document.getElementById("imgVetrina");
	var data=document.getElementById("rilascio");
	var titolo=document.getElementById("titolo");		
	var imgDescrizione=document.getElementById("imgDescrizione");
	var prezzo=document.getElementById("prezzo");
	var specifiche=document.getElementById("specifiche");
	var descrizione=document.getElementById("descrizione");
	var sintetica=document.getElementById("sintetica");

	if(checkNomeSoftware(software)){
		if(checkImmagineVetrina(imgVetrina)){
			if(checkDataDiRilascio(data)){
				if(checkTitolo(titolo)){
					if(checkImmagineDescrizione(imgDescrizione)){
						if(checkDescrizione(specifiche)){
							if(checkDescrizione(descrizione)){
								if(checkDescrizione(sintetica)){
									if(checkPrezzo(prezzo)){
										document.getElementById("submit3").submit();
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return false;
}


function validateAggiungiCorso(){

	var corso=document.getElementById("corso");
	var imgVetrina=document.getElementById("imgVetrinaCorso");

	var titolo=document.getElementById("titoloCorso");		
	var imgDescrizione=document.getElementById("imgDescrizioneCorso");
	var numEsami=document.getElementById("numEsami");
	var specifiche=document.getElementById("specificheCorso");
	var descrizione=document.getElementById("descrizioneCorso");
	var sintetica=document.getElementById("sinteticaCorso");
	if(checkNomeSoftware(corso)){
		if(checkImmagineVetrina(imgVetrina)){
			if(checkTitolo(titolo)){
				if(checkImmagineDescrizione(imgDescrizione)){
					if(checkNumeroEsami(numEsami)){
						if(checkDescrizione(specifiche)){
							if(checkDescrizione(descrizione)){
								if(checkDescrizione(sintetica)){
									document.getElementById("submit4").submit();
								}
							}
						}
					}
				}
			}
		}
	}
	return false;
}

function validateRecoverPassword(){
	var email= document.getElementById("email");
	if(checkEmail(email)){
		document.getElementById("submit").submit();
	}
	return false;
}