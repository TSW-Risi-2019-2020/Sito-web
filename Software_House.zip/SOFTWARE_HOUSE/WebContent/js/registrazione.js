function Registrazione() 
	{
		     var password = document.registrazione.password.value;
		     var conferma= document.registrazione.conferma.value;
		     var data=document.registrazione.data.value;
		  
		   	//Verifica l'uguaglianza tra i campi PASSWORD e CONFERMA PASSWORD
		    if (password != conferma) 
		    {
		           alert("La password confermata \u00E8 diversa da quella scelta");
		           document.registrazione.conferma.value = "";
		           document.registrazione.conferma.focus();
		           return false;
		    }	
	}

