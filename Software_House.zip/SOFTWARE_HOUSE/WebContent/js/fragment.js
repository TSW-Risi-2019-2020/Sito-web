var fragmentName=window.location.hash.substr(1);
	$.ajax
		({
			type: "GET",
			url: "GetSoftwareDetails",
			data: "fragment="+fragmentName,
			success: function(response){
			}
		});